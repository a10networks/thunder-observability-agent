#!/usr/bin/python
# Copyright 2023 A10Networks Inc.. All Rights Reserved.
# THUNDER OBSERVABILITY AGENT END USER SOFTWARE LICENSE AGREEMENT
"""
Configure utility methods for toa framework.
To use, simply 'import Helper' and use it!
"""
__author__ = 'Dinesh Kumar Lohia (DLohia@a10networks.com)'

from common.toa_logging import Logging
from common.toa_constant import Constant
from common.toa_utils import Utils
from handler.aws_handler import AWSHandler
from handler.azure_handler import AzureHandler
from processor.metric_processor import MetricProcessor
from processor.log_processor import LogProcessor
from concurrent.futures import ThreadPoolExecutor
class Helper:
    
    _logger = Logging().get_logger("Helper")
    
    def __init__(self):
        pass
    
    @staticmethod
    def init():
        try:
            Utils.load_properties()
            Utils.load_config()
            Utils.load_collect_provider() 
            Helper.load_autoscale_thunders()
            Utils.load_publish_provider()
            if(Utils.validate()):
                Helper.process()
        except Exception as exp:
            Utils._logger.debug(exp)
            return False
        
    @staticmethod
    def process():
        try:
            with ThreadPoolExecutor(max_workers=int(Utils._main.get(Constant._THREADPOOL_MAX_WORKERS))) as executor:
                executor.map(LogProcessor().process, Utils._thunders.get(Constant._THUNDERS))
                executor.map(MetricProcessor().process, Utils._thunders.get(Constant._THUNDERS))
        except Exception as exp:
            Utils._logger.debug(exp)

    @staticmethod
    def load_autoscale_thunders():
        if(Utils.is_valid(Utils._thunders)):
            if(Utils.is_valid(Utils._thunders.get(Constant._AUTOSCALE)) and Utils._thunders.get(Constant._AUTOSCALE)==1 and Utils.is_valid(Utils._thunders.get(Constant._PROVIDER), Utils._thunders.get(Constant._THUNDERS), Utils._thunders.get(Constant._THUNDERS)[0], Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._USERNAME), Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._PASSWORD), Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._RESOURCE_ID))):
                if(Utils._thunders.get(Constant._PROVIDER)==Constant._AWS):
                    handler = AWSHandler(Utils._thunders.get(Constant._THUNDERS)[0], Constant._AWS_BOTO3_SERVICE_AUTOSCALING)
                    Utils._thunders[Constant._THUNDERS] = handler.collect_thunders_from_autoscale()
                elif(Utils._thunders.get(Constant._PROVIDER)==Constant._AZURE):
                    handler = AzureHandler(Utils._thunders.get(Constant._THUNDERS)[0], None)
                    handler.token(Constant._AZURE_MANAGEMENT_RESOURCE)
                    Utils._thunders[Constant._THUNDERS] = handler.collect_thunders_from_autoscale()
                else:
                    Utils._logger.warn((Constant._ERROR_INVALID_THUNDER_AUTO).format(Utils._thunders.get(Constant._PROVIDER)))
                    Utils._thunders=None
            elif(Utils.is_valid(Utils._thunders.get(Constant._THUNDERS)) and Utils.is_valid(Utils._thunders.get(Constant._THUNDERS)[0]) and Utils.is_valid(Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._IP), Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._USERNAME), Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._PASSWORD), Utils._thunders.get(Constant._THUNDERS)[0].get(Constant._RESOURCE_ID))):
                pass
            else:
                Utils._thunders=None
                Utils._logger.warn(Constant._ERROR_INVALID_THUNDER_PARAMETERS)
                
            if(Utils.is_valid(Utils._thunders) and Utils.is_valid(Utils._thunders.get(Constant._THUNDERS))):
                Utils._logger.info(Constant._INFO_ACTIVE_THUNDERS_COUNT.format(str(len(Utils._thunders.get(Constant._THUNDERS))), [value['ip'] for value in Utils._thunders.get(Constant._THUNDERS)] ))
                
            else:
                Utils._logger.info(Constant._INFO_ACTIVE_THUNDERS_COUNT.format(str(0),""))