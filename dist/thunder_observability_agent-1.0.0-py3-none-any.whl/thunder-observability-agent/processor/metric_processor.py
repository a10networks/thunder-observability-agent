#!/usr/bin/python
# Copyright 2023, A10 Networks Inc. All Rights Reserved.
# THUNDER OBSERVABILITY AGENT END USER SOFTWARE LICENSE AGREEMENT
"""
Processing engine to process metrics information from thunder to configured provider.
To use, simply 'import Metric' and use it!
"""
__author__ = 'Dinesh Kumar Lohia (DLohia@a10networks.com)'

from common.toa_constant import Constant
from common.toa_utils import Utils
from collections import ChainMap
import concurrent.futures
from common.toa_logging import Logging
from handler.thunder_handler import ThunderHandler
from handler.aws_handler import AWSHandler
from handler.vmware_handler import VMWareHandler
from handler.azure_handler import AzureHandler
from concurrent.futures import ThreadPoolExecutor

class MetricProcessor:
    
    _logger = Logging().get_logger("MetricProcessor")
    
    def process(self, thunder):
        if(Utils.is_valid(Utils._active_metric_provider)):
            if Utils._active_metric_provider==Constant._AWS_METRIC:
                self.process_aws_metric(thunder)
            elif Utils._active_metric_provider==Constant._AZURE_METRIC:
                self.process_azure_metric(thunder)
            elif Utils._active_metric_provider==Constant._VMWARE_METRIC:
                self.process_vmware_metric(thunder)
    
    def process_aws_metric(self, thunder):
        _metrics = self.collect_metric(thunder, None)
        if(Utils.is_valid(_metrics)):
            AWSHandler(thunder, Constant._AWS_BOTO3_SERVICE_CLOUDWATCH).publish_metric(_metrics)
       
    def process_vmware_metric(self, thunder): 
        _metrics = self.collect_metric(thunder, None)
        if(Utils.is_valid(_metrics)):
            handler = VMWareHandler(thunder, None)
            handler.token()
            handler.publish_metric(_metrics)
       
    def process_azure_metric(self, thunder): 
        handler = AzureHandler(thunder, None)
        handler.token(Constant._AZURE_MONITORING_RESOURCE)
        handler.log(self.collect_metric(thunder, handler.publish_metric))
        
    def collect_metric(self, thunder, callback):
        metric_data = []
        handler = ThunderHandler(None, None, thunder, None, callback=callback)
        handler.token()
        handler.header()
        if(not Utils.is_valid(handler._token)):
            return None
        """
        thunders1=[
                    handler.collect_metric_cpu,
                    handler.collect_metric_new,
                    handler.collect_metric_memory,
                    handler.collect_metric_disk,
                    handler.collect_metric_throughput,
                    handler.collect_metric_interface,
                    handler.collect_metric_disk_server,
                    handler.collect_metric_transaction,
                    handler.collect_metric_server_per,
                    handler.collect_metric_cpu,
                    handler.collect_metric_memory,
                    handler.collect_metric_session,
                    handler.collect_metric_packet_drop,
                    handler.collect_metric_packet_rate,
                    handler.collect_metric_server_error,
                    handler.collect_metric_ssl
                  ]
        """
        thunders = [ThunderHandler(metric=metric, date=None, thunder=handler._thunder, token=handler._token, callback=callback) for metric in Utils._metrics]
        with ThreadPoolExecutor(max_workers=int(Utils._main.get(Constant._THREADPOOL_MAX_WORKERS))) as collect:
            futures = [collect.submit(thunder.collect_metric) for thunder in thunders]
            #futures = [collect.submit(thunder) for thunder in thunders]
            for future in concurrent.futures.as_completed(futures):
                if future.result() is not None:
                    metric_data.append(future.result())
            handler.logoff()
            return dict(ChainMap(*metric_data))
    
    